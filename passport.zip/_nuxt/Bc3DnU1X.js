import{M as o}from"./CIfiQjAJ.js";const p=o("/logo.png");export{p as _};
